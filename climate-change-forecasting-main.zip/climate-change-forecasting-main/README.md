# climate-change-forecasting
In this project, I analyze the change in temperatures across globe from the 17th century until now and build a multivariate deep learning based time series model to forecast Average temperature for any given country (initially trained for U.S data. My RNN model attempts at forecasting future value based on historical data.
